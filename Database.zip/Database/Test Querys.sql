Select CustomerID, EmployeeID from bikeshop.onlinetracker;
Select CustomerID, FirstName, LastName, State from bikeshop.customer;
Select EmployeeID, FirstName, LastName, Email from bikeshop.repairteam;
Select * from bikeshop.ticket; 